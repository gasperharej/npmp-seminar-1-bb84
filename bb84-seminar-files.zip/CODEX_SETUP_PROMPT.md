# Codex prompt — BB84 seminar: okolje, začetni simulator in literatura

You are a careful senior Python engineer and research assistant. Work DIRECTLY in the current working directory, which MUST be the root of the existing private Git submodule repository:

`~/Documents/ul-fri-msc/2026-2027/semester-1/unconventional-computing/labs/seminar-1-bb84`

The parent `ul-fri-msc` repository is not your work area. If the current working directory is not the BB84 Git repo, stop and explain before changing files. Do not run `git init`, change remotes, change visibility, create another submodule, or modify the parent repository or its `.gitmodules`. Do not commit or push without my approval.

## Research context — this exact topic was APPROVED by the professor

**Official Slovenian title (use it exactly):**

> Vpliv šuma in velikosti kontrolnega vzorca na zaznavanje prisluškovanja v protokolu BB84

Course: Nekonvencionalne platforme in metode procesiranja (NPMP), magistrski študij, UL FRI.

**Research question:** Kako stopnja kvantnega šuma in velikost kontrolnega vzorca vplivata na verjetnost pravilnega zaznavanja prisluškovanja v protokolu BB84?

Research approach: simulate BB84 with Python and Qiskit, vary noise and the number of publicly checked sifted bits, compare intercept-resend present/absent, and compare later experiments with mathematical expectations. The ultimate outcome is detection performance at an explicitly controlled false-alarm level, not merely QBER.

I want a functioning, minimal initial implementation and clean environment FIRST, not the entire thesis or fabricated results.

## A. Inspect before changing anything

1. Inspect `pwd`, `git rev-parse --show-toplevel`, `git status --short`, existing files and current README.
2. Inspect OS, Python availability, Zsh, `ZDOTDIR`, current effective Zsh startup files, any dotfiles symlinks, and existing dotenv/direnv configuration. Note that Zsh config may live in `~/.config/zsh/` and be tracked by a separate dotfiles repository.
3. Check whether `.venv`, `.envrc`, `.env`, `pyproject.toml`, dependencies, Qiskit or a literature directory already exist. Preserve useful existing content and all uncommitted changes.
4. Avoid destructive commands. Back up any configuration you need to change outside this repository and request explicit approval before modifying global shell/dotfiles configuration or installing system packages.
5. Do not modify unrelated projects and never write secrets or real user names into shared config.

## B. Python project and dependencies

Use a standard Python `.venv` (prefer a supported Python 3.12; otherwise compatible 3.11/3.13 after verifying wheel support). No Docker, Conda, cloud IBM account, GPU, or system-wide pip installs.

Set up a valid importable `src/` package using `pyproject.toml` and editable installation. Install or define compatible packages:

- `qiskit`, `qiskit-aer` — actual circuit simulations, including noise models
- `numpy`, `pandas`, `matplotlib`
- `scipy` — exact binomial tests / theoretical reference calculations
- `pytest`, `ruff` — tests and linting

Use supported up-to-date APIs compatible with installed versions. Do not use old `from qiskit import Aer` / `execute` examples that might no longer be supported; prefer `from qiskit_aer import AerSimulator` and verified Qiskit circuits.

Create an idempotent `scripts/bootstrap.sh` that creates `.venv`, installs reproducible dependencies and the project package, and reports version checks. Maintain a portable pinned dependency lock (e.g. generated `requirements.lock` using `pip-tools` or an equally reproducible standard workflow). Do not embed absolute local paths in the lockfile. The script must not install anything when simply `cd`-ing into the directory.

## C. Automatic shell activation with direnv — important

When I type `cd` into this BB84 folder, `.venv/bin/python` must become the default Python automatically. When I leave it, my original PATH must be restored. I already use Zsh, customized dotfiles and possibly dotenv plugins; do not replace their configuration.

1. Check whether direnv is installed; install it through the local package manager only with my approval if elevated privileges are needed.
2. Determine the REAL effective Zsh rc file using `ZDOTDIR`, sourced files, symlinks and shell state. Reuse a working direnv hook if already present. If missing, propose the smallest idempotent change — usually `eval "$(direnv hook zsh)"` near the end of the effective Zsh initialization — and request approval before altering my global dotfiles.
3. In this project create a reviewable, committed `.envrc` equivalent to:

```bash
if [ -d .venv ]; then
    export VIRTUAL_ENV="$PWD/.venv"
    PATH_add "$VIRTUAL_ENV/bin"
else
    log_status 'Missing .venv; run ./scripts/bootstrap.sh once.'
fi

dotenv_if_exists .env
```

Use actual supported direnv syntax and verify it. No `source .venv/bin/activate` in `.zshrc`, no recurring package install in `.envrc`, and no secrets in `.envrc`.

4. Create `.env.example` with `BB84_SEED=42`, `BB84_SHOTS=1024`, `BB84_OUTPUT_DIR=results`; create `.env` from it only if absent, never overwrite an existing one; ignore `.env` in Git. Avoid conflicting duplicate dotenv auto-loaders.
5. Require the usual one-time `direnv allow .` after inspecting `.envrc`; document it and do not automatically authorize any existing unreviewed configuration.
6. Test `which python`, `sys.prefix`, Zsh hook behavior on leaving/re-entering the directory, and imports. If you cannot emulate an interactive shell, report the unverified point and exact manual check, never claim success without testing.
7. Document the classmate's steps on their own Linux machine. Only the repo-local `.envrc` and `.env.example` belong in Git; their actual `.venv`, `.env` and dotfiles are separate.

## D. Keep the repository simple

Target directory structure (create folders only if needed; no boilerplate architecture):

```text
seminar-1-bb84/
├── README.md
├── pyproject.toml
├── requirements.lock
├── .gitignore
├── .env.example
├── .envrc
├── src/bb84/
│   ├── __init__.py
│   ├── __main__.py
│   ├── protocol.py
│   ├── eavesdropper.py   # add only if useful at this stage
│   ├── noise.py          # add only if useful at this stage
│   └── metrics.py
├── experiments/
├── tests/
├── scripts/
│   ├── bootstrap.sh
│   └── fetch_literature.py
├── literature/
│   ├── README.md
│   ├── sources.json
│   ├── references.bib
│   └── pdfs/            # local, ignored
├── results/             # generated outputs, ignored unless curated
├── figures/             # generated plots, ignored unless curated
└── report/              # future LaTeX report in Slovenian
```

Use English paths and identifiers, but Slovenian for all seminar documentation, discussion, research questions, figure captions and future report.

## E. Minimal, CORRECT initial quantum simulator

Implement ONLY the BB84 foundation now, actually using Qiskit Aer quantum circuits:

- Alice encodes uniformly sampled bits with randomly chosen Z/X bases. States `|0>`, `|1>`, `|+>`, `|->` via X and H.
- Bob chooses Z/X bases independently and measures in that basis.
- Alice and Bob publicly compare bases, retain only matched positions, randomly choose `m` test bits **from the sifted positions**, disclose their values, and compute `QBER = errors / m`. Do not confuse `m` with the raw number `N` of transmitted qubits.
- The publicly compared bits are removed from any remaining candidate key. It is NOT a final secure key.
- Fixed master seed and explicit RNG passing; keep random draws and shots reproducible across runs.
- Provide `python -m bb84` demo with `N`, sifted length, compared sample size, number of errors, and QBER. It must handle insufficient sifted bits and `m=0` clearly without fake zero-error claims.
- Provide small pytest tests: four states, matching-basis correctness without noise/Eve, approximately uniform mismatched-basis outcomes, expected sifting rate, QBER edge cases, sampling without replacement, deterministic behavior for a fixed seed.
- Keep performance in mind; using one Qiskit circuit for every signal in huge experiment grids is likely too slow. Initial demo can be small. For future large sweeps, use batched Qiskit circuits grouped by preparation/measurement settings or validate against a clearly labelled mathematical Monte Carlo model. Do not quietly present classical sampling as a quantum circuit simulation.
- Do NOT implement all experiments now. Keep interfaces lightweight and add only genuine tested functionality; no misleading placeholder results.

## F. Approved study methodology — document accurately, do not fabricate data

The main variables are:

- Noise level `lambda`, e.g. [0, 0.02, 0.05, 0.10, 0.20]. This is a **depolarizing channel parameter**, NOT directly the error probability/QBER.
- Control sample size `m`, e.g. [16, 32, 64, 128, 256, 512] bits AFTER matching bases; publicly compared and discarded.
- Eavesdropping condition `p=0` (no Eve) vs `p=1` (all qubits intercepted). Partial intercept `p=0.5` is optional secondary analysis.
- The number of transmitted signals `N` must be sufficient for the chosen `m` even after sifting; never silently shorten a requested sample.

The physical-model order MUST be specified: Alice prepares -> Eve may intercept/measure/reprepare -> one-qubit depolarizing channel applies once on Eve-to-Bob link -> Bob measures. Without Eve the same noise channel is applied after Alice preparation. Do not use a generic gate noise model that accidentally applies the noise multiple times to X and H gates. Use the channel as a single explicit operation on the transmitted state; test it independently.

Qiskit Aer docs define the one-qubit depolarizing channel as:

`D_lambda(rho) = (1-lambda) rho + lambda I/2`.

For these assumptions and matched bases:

- `q0 = lambda/2` without Eve.
- `q_eve = p/4` in an ideal channel.
- `q1 = lambda/2 + (1-lambda)*p/4` when this independent depolarizing channel is applied after intercept-resend.

Treat these as THEORETICAL predictions under a narrowly defined model, not universal QKD security results.

Detection must NOT equal "any QBER > 0" when noise is present. Plan an explicit test, e.g. one-sided exact binomial test under `H0: q=q0`, `H1: q>q0`, alpha=0.05, assuming known/calibrated baseline q0. Use SciPy's `binomtest(..., alternative='greater')` or an exactly equivalent precomputed threshold. Calculate and report:

- TPR (true-positive rate / detection probability)
- FPR (false-positive rate / false alarms)
- FNR (false-negative rate)
- measured QBER and uncertainty/95% confidence intervals
- analytical binomial test power for q1, compared with empirical proportions

For `lambda=0` and the "at least one error" criterion only, `1-(1-p/4)^m` gives the probability of observing an error. Explain that this **does not** generalize unchanged to a noisy channel. TPR/FPR describe a *decision under a chosen statistical test*, not a proof of actual attack attribution. Different unknown noise baselines can imitate the effect of Eve.

Plan:

E1. Validate the ideal simulator and standard intercept-resend: QBER ~0 without Eve and ~25% for full intercept without noise.

E2. Main study: independent repetitions across `(lambda, m, Eve absent/present)`, log seed, N, m, errors, QBER, alpha, detection decision. Output tidy CSV, TPR/FPR/FNR, confidence intervals and plots, once implemented in the NEXT phase.

E3. Validate simulation vs analytical q0, q1, binomial power, and identify smallest sample size m satisfying a given power at a fixed FPR target. Note clearly if target is not met in the tested grid.

Use pilot simulation sizes reasonable for CPU; increase after benchmarking. Never invent numbers, measurements, citations or results. The assignment should remain feasible as a ~10-page report and 10-minute presentation.

## G. Literature — FREE and downloadable, specially selected for this topic

Create `literature/sources.json`, `literature/references.bib`, `literature/README.md`, `literature/pdfs/` and `scripts/fetch_literature.py`. If these exact manifest/bibliography files have already been copied into this repository, preserve them and verify rather than replacing blindly.

**Required papers (exact identifiers, no substitutions):**

1. Bennett, C. H. & Brassard, G. (1984), *Quantum cryptography: Public key distribution and coin tossing* — original protocol; arXiv has a later scan upload, `2003.06557` — `https://arxiv.org/pdf/2003.06557`.
2. Gisin, N., Ribordy, G., Tittel, W., Zbinden, H. (2002), *Quantum cryptography* — BB84, bases, security intuition and attacks; arXiv `quant-ph/0101098` — `https://arxiv.org/pdf/quant-ph/0101098`.
3. Scarani, V. et al. (2009), *The security of practical quantum key distribution* — noise, practical limitations and assumptions; arXiv `0802.4155` — `https://arxiv.org/pdf/0802.4155`.
4. Cai, R. Y. Q. & Scarani, V. (2009), *Finite-key analysis for practical implementations of quantum key distribution* — finite sample statistics; arXiv `0811.2628` — `https://arxiv.org/pdf/0811.2628`.
5. Tomamichel, M., Lim, C. C. W., Gisin, N., Renner, R. (2012), *Tight finite-key analysis for quantum cryptography* — finite-size effects and security analysis; arXiv `1103.4130` — `https://arxiv.org/pdf/1103.4130`.
6. Fiorini, F., Pagano, M., Garroppo, R. G. & Osele, A. (2024), *Estimating Interception Density in the BB84 Protocol: A Study with a Noisy Quantum Simulator* — **very closely relevant** open-access study of noisy partial intercept-resend attacks, key length and detection; `https://www.mdpi.com/1999-5903/16/8/275/pdf`, fallback repository `https://arpi.unipi.it/handle/11568/1271727`. Journal: Future Internet 16(8), 275, DOI `10.3390/fi16080275`. Clearly distinguish our sample-size / fixed-FPR binomial detection design from its method.
7. Shor, P. W. & Preskill, J. (2000), *Simple Proof of Security of the BB84 Quantum Key Distribution Protocol* — OPTIONAL broader theoretical security context; arXiv `quant-ph/0003004` — `https://arxiv.org/pdf/quant-ph/0003004`.

Important bibliographic nuance: the original BB84 article is from **1984** even if the scanned copy was uploaded to arXiv in **2020**. Gisin's paper is a 2002 journal publication despite its earlier arXiv submission. Use verified years/DOIs rather than confusing submission dates with publication years. Finite-key analyses are not identical to this project's simplified intercept-resend detection test; explain their relevance without pretending their security proofs apply automatically.

Download script requirements:

- Download legally free PDF copies into `literature/pdfs/` using the listed URLs. The MDPI source has no arXiv ID: do not fabricate one; on failure show its journal landing page and institutional repository as manual alternatives.
- Use standard-library Python if practical; validate HTTP response and `%PDF-` bytes, reject HTML/challenge pages and truncated/empty content, write atomically, and skip existing valid files.
- Report each success and failure; never claim downloaded files exist unless verified.
- On failed URLs provide a manual arXiv abstract/page link; retry politely or use a verified alternative OPEN source only for the SAME article.
- Ignore downloaded PDF files in Git by default; track manifest, BibTeX and download script.
- Include exact document purpose and reading priority in Slovenian in `literature/README.md`.

Also link (no need to download as PDF):

- IBM Quantum QKD educational module: `https://qiskit.qotlabs.org/learning/modules/computer-science/quantum-key-distribution`
- Qiskit Aer depolarizing channel: `https://qiskit.github.io/qiskit-aer/stubs/qiskit_aer.noise.depolarizing_error.html`
- SciPy exact binomial test: `https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.binomtest.html`
- direnv Zsh hook: `https://direnv.net/docs/hook.html`

## H. NEW Slovenian README — replace outdated research plan

I want a **completely rewritten** README.md focused on my professor-approved title, not the old general study "effect of eavesdropping and noise". If the supplied README.md in this repo already matches this precise approved design, prefer preserving it and correcting only detected errors. Otherwise write a new README in Slovenian containing:

1. Exact approved title, UL FRI and NPMP, status of project.
2. Research question and 2–3 testable hypotheses specifically about **noise and control sample size**.
3. BB84 Alice / Eve / channel / Bob / basis sifting / random test sampling sequence.
4. Model and definitions of `N`, `m`, `lambda`, `p`, QBER, TPR, FPR, FNR, threshold and alpha.
5. Theoretical reference q0, q1, conditions of `p/4`, and ideal probability of at least one error.
6. Explicit statistical test at fixed false positive target, with limitations/assumptions.
7. Small pilot grids for E1–E3; distinguish planned from completed research.
8. Reproducible setup commands, direnv + dotenv use, testing, local simulator execution.
9. Links to the SEVEN open-access papers with exact titles and downloadable URLs; especially Cai & Scarani and Tomamichel et al.
10. Link to `literature/references.bib`, reproducible PDF fetching, and report plan in Slovenian.
11. Clear scope limitations: no false production-grade security, no real hardware, no unverified simulation results.
12. Simple checklist for environment, base simulator, Eve, noise, detection statistics, report.

Use English names for directories and code; Slovenian prose for README and research. Do not include fabricated results or tests falsely marked as passed.

## I. Git hygiene and collaborator readiness

Ignore `.venv/`, `.env`, `.direnv/`, cache, downloaded PDFs, temporary outputs, secrets and non-curated generated results; track `.envrc`, `.env.example`, pyproject, lockfile, source, tests, research design, manifests, BibTeX and scripts.

Ensure it is usable as a standalone private repository when a classmate clones it. Do not assume access to `ul-fri-msc` or my personal dotfiles. Explain simple branch/PR collaboration, but do NOT invite anyone or alter GitHub permissions.

## J. Run and verify, then report honestly

After writing files, run all feasible checks:

```bash
./scripts/bootstrap.sh
direnv allow .
python -m pytest
python -m ruff check .
python -m bb84
python scripts/fetch_literature.py
```

Also verify imports, project-local Python selection and safe behavior when leaving the project directory. Distinguish commands actually executed from commands merely documented. Confirm each PDF file that was actually downloaded.

Do not commit or push. Do not write the full seminar paper or invent any research results. End with a concise **Slovenian** report describing changed files, environment versions, test outcomes, download outcomes, unresolved issues and the single next recommended coding task (Eve / ideal intercept-resend validation).

**Execute the setup now. First inspect, then safely create, install, test and summarize.**

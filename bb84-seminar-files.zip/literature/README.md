# Literatura za raziskavo BB84

Brezplačni viri, izbrani za seminarsko nalogo **Vpliv šuma in velikosti kontrolnega vzorca na zaznavanje prisluškovanja v protokolu BB84**.

## Prednostni vrstni red branja

1. **Gisin et al., Quantum cryptography (2002)** — izberi razdelke o BB84, prisluškovanju in varnosti. [PDF](https://arxiv.org/pdf/quant-ph/0101098)
2. **Bennett & Brassard, Quantum cryptography: Public key distribution and coin tossing (1984)** — originalni protokol. [PDF](https://arxiv.org/pdf/2003.06557)
3. **Cai & Scarani, Finite-key analysis for practical implementations of quantum key distribution (2009)** — finite-size statistika in vpliv omejenega vzorca. [PDF](https://arxiv.org/pdf/0811.2628)
4. **Tomamichel et al., Tight finite-key analysis for quantum cryptography (2012)** — natančnejše varnostne meje za končne ključe. [PDF](https://arxiv.org/pdf/1103.4130)
5. **Scarani et al., The security of practical quantum key distribution (2009)** — fizikalne omejitve in šum. [PDF](https://arxiv.org/pdf/0802.4155)
6. **Fiorini et al., Estimating Interception Density in the BB84 Protocol: A Study with a Noisy Quantum Simulator (2024)** — **zelo neposredno povezan članek**: parcialni napad, šum, velikost podatkov in sklepanje; metodologijo uporabi kot primerjavo, ne kot predlogo za prepis. [PDF](https://www.mdpi.com/1999-5903/16/8/275/pdf)
7. **Shor & Preskill, Simple Proof of Security of the BB84 Quantum Key Distribution Protocol (2000)** — neobvezno za širšo razpravo o varnostnih dokazih. [PDF](https://arxiv.org/pdf/quant-ph/0003004)

Prenos na lokalni disk:

```bash
python scripts/fetch_literature.py
```

Skripta preveri format datoteke in neuspele prenose jasno označi. Povezave so zapisane v `sources.json`, citati pa v `references.bib`.

**Povezava z eksperimentom:** članka Cai–Scarani in Tomamichel idr. utemeljujeta pomen končne velikosti podatkov v QKD; ne predstavljata pa dokaza, da je naš preprosti binomski detektor napadov kriptografsko varen.

#!/usr/bin/env python3
"""Download openly accessible BB84 literature from literature/sources.json.

Usage (run from any directory): python scripts/fetch_literature.py
PDFs are for local study; commit the source manifest and BibTeX, not PDFs.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "literature" / "sources.json"
DEST = ROOT / "literature" / "pdfs"
MAX_SIZE = 30 * 1024 * 1024


def valid_pdf(path: Path) -> bool:
    if not path.is_file() or path.stat().st_size < 1000:
        return False
    with path.open("rb") as f:
        return f.read(5) == b"%PDF-"


def download(url: str, destination: Path) -> None:
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (compatible; UniversityResearchPDFDownloader/1.0)",
        "Accept": "application/pdf",
    })
    fd, name = tempfile.mkstemp(prefix=".download-", suffix=".tmp", dir=DEST)
    tmp = Path(name)
    try:
        with os.fdopen(fd, "wb") as out, urlopen(request, timeout=45) as response:
            content_type = response.headers.get("Content-Type", "").lower()
            first = response.read(8192)
            if not first.startswith(b"%PDF-"):
                raise ValueError(f"Response is not a PDF (Content-Type: {content_type!r})")
            out.write(first)
            total = len(first)
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_SIZE:
                    raise ValueError("PDF exceeds 30 MiB safety limit")
                out.write(chunk)
        if not valid_pdf(tmp):
            raise ValueError("Downloaded file did not pass PDF validation")
        os.replace(tmp, destination)
    finally:
        tmp.unlink(missing_ok=True)


def main() -> int:
    DEST.mkdir(parents=True, exist_ok=True)
    papers = json.loads(MANIFEST.read_text(encoding="utf-8"))
    failures = 0
    for paper in papers:
        url = paper["pdf_url"]
        target = DEST / paper["filename"]
        if target.name != paper["filename"] or target.parent != DEST:
            raise ValueError("Invalid manifest filename")
        if valid_pdf(target):
            print(f"SKIP   {target.name} — valid existing PDF")
            continue
        try:
            download(url, target)
        except (HTTPError, URLError, TimeoutError, OSError, ValueError) as exc:
            failures += 1
            print(f"FAILED {target.name}: {exc}")
            print(f"       Manual PDF: {url}")
            if paper.get("arxiv"):
                print(f"       Abstract: https://arxiv.org/abs/{paper['arxiv']}")
            elif paper.get("fallback_url"):
                print(f"       Institutional repository: {paper['fallback_url']}")
        else:
            print(f"OK     {target.name} ({target.stat().st_size:,} bytes)")
    print(f"\nDone: {len(papers) - failures}/{len(papers)} papers available as valid PDFs")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
